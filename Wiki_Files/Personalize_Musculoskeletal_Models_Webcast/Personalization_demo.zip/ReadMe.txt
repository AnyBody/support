1. Please correct your AnyBody Managed Model Repository path in the libdef.any file

2. Standing Model is a normal Standing Model example from the AMMR, which was changed by adding segment morphing for femur and tibia.
Please load StandingModel\Demo.main.any to see this modification.

3. MoCap model is a modification of the normal MoCap model example from the AMMR, which was also adjusted to incorporate subject-specific code.
Please load MoCapModel\Demo-MoCap.main.any to see modifications. Please note that some changes were also applied to use a local  anthropometric scaling law 
(HumanModel.any, line 32, new ScalingLengthMassFat.any with modifications at line 124).

