import os

def Diff(context,Value,delta,filename):
	filelocation = os.path.join(filename)
		

	try:
		f = open(filelocation, 'r')	
		if f is not None:
			content=float(f.read())
			f.close()
		else:
			content=0
	except IOError:
		content=0	
	


		
		
		

	f = open(filelocation, 'w')	
	if f is not None:
		f.write("%s" %Value)
		f.close()
	else:
	    return False
	
	t=(Value-content)/delta
	
	return t
	

	
	